package com.meliodas.SenkoArea;
import me.wiefferink.areashop.AreaShop;
import me.wiefferink.areashop.managers.FileManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

public class SenkoArea extends JavaPlugin {
    private Connection connection;
    private String host, database, username, password;
    private int port;
    static Statement statement;
    static FileManager lmao;
    static AreaShop areaShop;
    private static final Logger log = Logger.getLogger("Minecraft");
    @Override
    public void onDisable() {
        log.info(String.format("[%s] Disabled Version %s", getDescription().getName(), getDescription().getVersion()));
    }

    @Override
    public void onEnable() {
        log.info("I have been summoned");
        areaShop = (AreaShop)Bukkit.getPluginManager().getPlugin("AreaShop");
        lmao = areaShop.getFileManager();
        host = "remotemysql.com";
        port = 3306;
        database = "Fbx3QgSAmp";
        username = "Fbx3QgSAmp";
        password = "KYH7NRLflh";
        try {
            openConnection();
            statement = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        try {
            JDA jda = JDABuilder.createDefault("NzAxNDM2ODMzODA3OTkwODM3.Xpxd9Q.b4vt9IoTtAHDAp0BFbgEZqCdbgY")
                    .addEventListeners(new SenkoListener())
                    .setActivity(Activity.streaming("Zain's PP", "https://www.twitch.tv/monstercat"))
                    .build();
            jda.awaitReady();
        }catch (Exception err) {
            log.info(err.toString());
        }
    }
    public void openConnection() throws SQLException, ClassNotFoundException {
        if (connection != null && !connection.isClosed()) {
            return;
        }

        synchronized (this) {
            if (connection != null && !connection.isClosed()) {
                return;
            }
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://" + this.host+ ":" + this.port + "/" + this.database, this.username, this.password);
        }
    }

}
