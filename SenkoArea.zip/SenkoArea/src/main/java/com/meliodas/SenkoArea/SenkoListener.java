package com.meliodas.SenkoArea;
import me.wiefferink.areashop.regions.RentRegion;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.UUID;

import static com.meliodas.SenkoArea.SenkoArea.*;

public class SenkoListener extends ListenerAdapter {
    UUID uuid = null;
    public void onMessageReceived(MessageReceivedEvent event) {
        Message message = event.getMessage();
        MessageChannel channel = event.getChannel();
        String messageraw = message.getContentRaw();
        String[] arrayboi = messageraw.split(" ");
        String playerid="potato";
        if(arrayboi[0].equals("!as-extend")) {
            Bukkit.getLogger().info("Should work "+ arrayboi[0]);
            try {
                ResultSet result = statement.executeQuery("SELECT player_id FROM synced_players WHERE identifier = "+event.getAuthor().getId()+";");
                if (result.next() == false) { Bukkit.getLogger().info("ResultSet in empty in Java"); } else { do { playerid = result.getString("player_id");} while (result.next()); }

                if(!playerid.equals("potato")) {
                    ResultSet result2 = statement.executeQuery("SELECT uuid FROM player WHERE id = " + playerid + ";");
                    if (result2.next() == false) {
                        Bukkit.getLogger().info("ResultSet2 in empty in Java");
                    } else {
                        do {
                            String uuidstr = result2.getString("uuid");
                            uuid = UUID.fromString(uuidstr);
                        } while (result2.next());
                    }
                }
            } catch (SQLException throwables) {
                event.getChannel().sendMessage("Errorz").queue();
                throwables.printStackTrace();
            }
            if (playerid.equals("potato")) {
                channel.sendMessage("You have to be linked!").queue();
            } else {
                    OfflinePlayer player = Bukkit.getOfflinePlayer(uuid);
                    EmbedBuilder embed = new EmbedBuilder();
                    embed.setColor(new Color(0xfd8061));
                    embed.setThumbnail(event.getMessage().getAuthor().getAvatarUrl());
                    embed.setFooter("Made by " + event.getAuthor().getAsTag(),event.getAuthor().getEffectiveAvatarUrl());
                    if(arrayboi.length == 1) {
                        embed.setTitle("Provide the name of your area");
                        embed.setDescription("You must provide the name of your area to use this command");
                        channel.sendMessage(embed.build()).queue();
                    } else {
                                RentRegion region = lmao.getRent(arrayboi[1]);
                                if (region == null) {
                                    embed.setTitle("Could not find the specified region");
                                    embed.setDescription("Maybe try !as-me");
                                    channel.sendMessage(embed.build()).queue();
                                } else {
                                    Bukkit.getLogger().info(uuid.toString());
                                    if (region.isRenter(uuid)) {
                                        Bukkit.getScheduler().runTask(areaShop, region::extend);
                                        embed.setTitle(player.getName());
                                        embed.setDescription("Your rent has been renewed, congrats");
                                        channel.sendMessage(embed.build()).queue();
                                    } else {
                                        embed.setTitle("You do not own that region");
                                        channel.sendMessage(embed.build()).queue();
                                    }
                                }

                    }
            }
        }
    }
}
